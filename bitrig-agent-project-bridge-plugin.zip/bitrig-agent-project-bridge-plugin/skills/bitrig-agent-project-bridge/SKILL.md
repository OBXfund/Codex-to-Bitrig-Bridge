---
name: bitrig-agent-project-bridge
description: Create a native Bitrig Agent project from any local Codex-created iOS project so Bitrig Remote can open and run it on iPhone. Use when the user asks to add a Codex iOS project to Bitrig, make a project visible under Bitrig Remote Agent, create a Bitrig Agent wrapper, or bridge a local Swift/SwiftUI/Xcode project into Bitrig without relying on Classic imports or plist-only project-index edits.
---

# Bitrig Agent Project Bridge

Use this skill to turn a local Codex iOS project into a uniquely named, Bitrig-native Agent project visible under **Agent** in Bitrig and Bitrig Remote.

This skill intentionally combines the reliable native bridge workflow with the richer Codex Agent Creator behavior:

- Resolve a source project from either an absolute path or a specific project name.
- Reject generic identities such as `New Project`, `App`, `Agent`, or `Untitled`.
- Generate a unique visible Agent name, usually `<SourceName>Agent`.
- Preserve the source project name and checkout path visibly in the generated app.
- Require a real buildable iPhone app target that runs in Bitrig/Xcode Simulator, not just metadata or a Classic import.

## Core Rule

Create the project through Bitrig's native Agent creation UI. Do not rely on manual `Projects.json` or `app.bitrig.AppIntents.ProjectIndex` insertion as the primary path; Bitrig prunes records that are not backed by native Agent state.

## Workflow

1. Prefer the one-command push/run path when the user wants the project to work in Bitrig Remote.
   - Existing project path:
     ```bash
     python3 scripts/push_codex_ios_to_bitrig_agent.py --project /absolute/path/to/project
     ```
   - Existing project name:
     ```bash
     python3 scripts/push_codex_ios_to_bitrig_agent.py --name "Project Name"
     ```
   - Known existing Agent name:
     ```bash
     python3 scripts/push_codex_ios_to_bitrig_agent.py --project /absolute/path/to/project --agent-name ExactAgentName
     ```
   - This delegates to the Codex Bridge Remote Preview lane, creates or reuses native Bitrig Agent state, verifies iPhone capability, writes user-readable logs, and runs `live-ready` unless `--no-run` is supplied.
   - Use `--dry-run` first when the identity or overwrite behavior is uncertain.
2. Resolve and inspect the Codex project manually when prompt-based Bitrig creation is needed.
   - If the user gave a path, run `scripts/prepare_bitrig_agent_prompt.py --project /absolute/path/to/project`.
   - If the user gave only a specific project name, run `scripts/prepare_bitrig_agent_prompt.py --name "Project Name"`.
   - If the user gave neither, ask one concise question: "What Codex iOS project path or project name should Bitrig Agent represent?"
   - Confirm it detects an iOS-capable checkout: `.xcodeproj`, `.xcworkspace`, `Package.swift`, `project.yml`, or Swift files.
   - Use the generated `agentName` as the visible Bitrig project name.
   - Use the generated prompt unless the user asks for different branding or app copy.
3. Open Bitrig's native Agent project creator.
   - Activate Bitrig with `open -a Bitrig` or `osascript`.
   - In Bitrig, use the Agent project list `+` button or `File > New Project`.
   - Make sure the prompt composer shows `Agent`, not Classic.
4. Paste and submit the generated prompt.
   - Put the prompt on the clipboard with `pbcopy < /path/to/generated-prompt.txt`.
   - Paste into the Bitrig New Project text field and submit.
   - Wait until Bitrig reports a successful build or shows a concrete error.
5. Verify the native Agent result.
   - Run `scripts/verify_bitrig_agent_project.py --name "Project Name"`.
   - Confirm:
     - `ProjectIndex` has the newest row as `source=agent`.
     - `~/Library/Bitrig/Projects.json` has the project with `iPhone=true`.
     - `~/Library/Bitrig/Projects/<id>/Project.json` exists and has an iOS application target.
     - `~/Library/Bitrig/Projects/<id>/BitrigAgent.json` exists and references the source checkout.
     - Bitrig's Mac Agent list visually shows the project.
6. Run it like a real app.
   - Launch the project in Bitrig/Xcode iPhone Simulator.
   - Confirm the app process runs and the Agent shell opens as an iPhone app.
   - Prefer the Codex Bridge `live-ready` or `mirror-live --launch-first` path when available.
7. Ask the user to refresh Bitrig Remote and check **Agent** for the project.
   - Do not claim Remote is verified until the user confirms it appears and opens on iPhone.

## Prompt Requirements

The prompt sent to Bitrig must be generic for any Codex iOS project:

- Include the derived `agentName`, source project name, and absolute checkout path when known.
- Include the absolute Codex checkout path.
- Ask for a native Bitrig Agent project, not a Classic import.
- Ask for an iPhone-only, buildable SwiftUI shell for Bitrig Remote.
- Require a real iOS application target with a SwiftUI App entry point, ContentView, and unique bundle identifier.
- Never leave the visible project name as `New Project`.
- Never reuse the source app's bundle identifier for the Agent shell.
- Ask Bitrig to include a local `BitrigAgent.json` metadata file with at least:
  - `kind: "agent-project"`
  - `name`
  - `sourceProjectName`
  - `sourceProjectPath`
  - `platforms: ["iPhone"]`
  - `bundleIdentifier`
- Preserve project identity without trying to copy or compile the entire original repo unless the user explicitly requests that.

## Name And Identity Rules

- If the source project is `CubeIdeaLab`, default the visible Agent name to `CubeIdeaLabAgent`.
- If that Agent name already exists in Bitrig metadata, append a short stable suffix from the source path.
- If the user gives a generic name, stop and ask for a specific source project path or project name.
- Keep the source project name and path visible in the app UI so Bitrig Remote users can tell which Codex project they opened.

## Real App Requirements

The Agent project must run like an iPhone app:

- It must have an iOS application target in `Project.json`.
- It must build and launch in the Bitrig/Xcode iPhone simulator.
- It must have a unique `PRODUCT_BUNDLE_IDENTIFIER`.
- It should be lightweight and preview-data based unless the user explicitly asks to wire source services.
- It must not be a Classic import, a metadata-only project, or a stale Projects.json/plist record.

## Native UI Automation Notes

Use macOS Accessibility automation when direct UI work is needed:

```bash
osascript -e 'tell application "Bitrig" to activate'
osascript -e 'tell application "System Events" to tell process "Bitrig" to click menu item "New Project" of menu "File" of menu bar 1'
pbcopy < /tmp/bitrig-agent-prompt.txt
osascript -e 'tell application "System Events" to tell process "Bitrig" to keystroke "v" using command down'
```

Coordinates may vary. Prefer named menu items and screen captures over blind clicks. If using coordinates, capture the screen before submitting.

## Troubleshooting

- If the project appears in Classic only, it is not ready for Bitrig Remote Agent. Create it again through the Agent New Project composer.
- If manual records disappear after relaunch, stop editing plist/JSON and use the native UI path.
- If Bitrig creates a project but the index has not updated yet, close the project window back to the Agent list and wait a few seconds.
- If the build fails, inspect Bitrig's shown error first. For shell projects, fix the generated Bitrig project files under `~/Library/Bitrig/Projects/<id>`, then let Bitrig rebuild.
- Keep old Classic rows unless the user explicitly asks to delete them.

## Resources

- `scripts/push_codex_ios_to_bitrig_agent.py`: one-command path that pushes a Codex iOS project into native Bitrig Agent state, verifies it, and optionally launches the live simulator preview through Codex Bridge.
- `scripts/prepare_bitrig_agent_prompt.py`: resolve project identity, generate a unique Agent name, inspect iOS capability, and write the Bitrig Agent creation prompt.
- `scripts/verify_bitrig_agent_project.py`: verify the newest native Agent project by name across Bitrig's index, catalog, project folder, and metadata.
- `references/native-agent-workflow.md`: detailed notes about why native Agent creation is required and how to recover from common false positives.
