#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any


CODEX_BRIDGE = Path(
    os.environ.get(
        "BITRIG_CODEX_BRIDGE",
        str(Path.home() / "Documents" / "Codex Bridge" / "tools" / "codex_to_bitrig_remote_viewer.py"),
    )
)
LOWER_BRIDGE = Path(
    os.environ.get(
        "BITRIG_LOWER_BRIDGE",
        str(Path.home() / "Documents" / "Bitrig Test" / "tools" / "codex_iphone_to_bitrig.py"),
    )
)


def shell_join(command: list[str]) -> str:
    return " ".join(shlex.quote(part) for part in command)


def exactly_one_identity(args: argparse.Namespace) -> None:
    identities = [args.new, args.project, args.name]
    if sum(bool(value) for value in identities) != 1:
        raise SystemExit("Provide exactly one of --new, --project, or --name.")


def resolved_project_path(path: str | None) -> str | None:
    if not path:
        return None
    project = Path(path).expanduser().resolve()
    if not project.is_dir():
        raise SystemExit(f"Project path is not a directory: {project}")
    return str(project)


def run_command(command: list[str], timeout: float) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, text=True, capture_output=True, check=False, timeout=timeout)


def json_stdout(result: subprocess.CompletedProcess[str] | None) -> dict[str, Any]:
    if result is None or not result.stdout.strip():
        return {}
    try:
        payload = json.loads(result.stdout)
        return payload if isinstance(payload, dict) else {}
    except json.JSONDecodeError:
        return {}


def remote_preview_summary(stdout: str) -> dict[str, str]:
    summary: dict[str, str] = {}
    for line in stdout.splitlines():
        if line.startswith("Status: "):
            summary["status"] = line.removeprefix("Status: ").strip()
        elif line.startswith("Session: "):
            summary["sessionPath"] = line.removeprefix("Session: ").strip()
        elif line.startswith("Summary: "):
            summary["summaryPath"] = line.removeprefix("Summary: ").strip()
        elif line.startswith("iPhone next step: "):
            summary["iphoneNextStep"] = line.removeprefix("iPhone next step: ").strip()
    return summary


def compact_live_ready(payload: dict[str, Any]) -> dict[str, Any]:
    commands = payload.get("commands") if isinstance(payload.get("commands"), dict) else {}
    return {
        "status": payload.get("status"),
        "agentName": payload.get("agentName"),
        "bundleId": payload.get("bundleId"),
        "macLive": payload.get("macLive"),
        "device": payload.get("device"),
        "process": payload.get("pidOutput"),
        "liveSummaryPath": payload.get("liveSummaryPath"),
        "remoteProofPath": payload.get("remoteProofPath"),
        "nextAction": payload.get("nextAction"),
        "proofDryRun": commands.get("proofDryRun"),
        "recordProof": commands.get("recordProof"),
        "refreshGo": commands.get("refreshGo"),
    }


def remote_preview_command(args: argparse.Namespace) -> list[str]:
    command = [
        sys.executable,
        str(CODEX_BRIDGE),
        "--bridge",
        str(LOWER_BRIDGE),
        "remote-preview",
        "start",
    ]
    if args.new:
        command.extend(["--new", args.new])
    if args.summary:
        command.extend(["--summary", args.summary])
    project = resolved_project_path(args.project)
    if project:
        command.extend(["--project", project])
    if args.name:
        command.extend(["--name", args.name])
    if args.agent_name:
        command.extend(["--agent-name", args.agent_name])
    if args.project_id:
        command.extend(["--project-id", args.project_id])
    if args.overwrite:
        command.append("--overwrite")
    if not args.refresh_bitrig:
        command.append("--no-refresh-bitrig")
    else:
        command.extend(["--refresh-delay", str(args.refresh_delay)])
    if args.no_run:
        command.append("--no-run")
    if args.dry_run:
        command.append("--dry-run")
    command.extend(["--automate-timeout", str(args.automate_timeout)])
    command.extend(["--verify-timeout", str(args.verify_timeout)])
    command.extend(["--control-timeout", str(args.control_timeout)])
    command.extend(["--session-timeout", str(args.session_timeout)])
    command.extend(["--max-repairs", str(args.max_repairs)])
    return command


def live_ready_command(args: argparse.Namespace) -> list[str]:
    command = [
        sys.executable,
        str(CODEX_BRIDGE),
        "live-ready",
        "--profile",
        args.profile,
        "--launch-timeout",
        str(args.launch_timeout),
    ]
    if args.no_write_live_ready:
        command.append("--no-write")
    if args.json:
        command.append("--json")
    return command


def public_result(
    args: argparse.Namespace,
    start_command: list[str],
    start_result: subprocess.CompletedProcess[str] | None,
    live_command: list[str] | None,
    live_result: subprocess.CompletedProcess[str] | None,
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "schemaVersion": "1.0",
        "goal": "Push a Codex iOS project into native Bitrig Agent state and run it like a real iPhone app.",
        "mode": "dry-run" if args.dry_run else "run",
        "remotePreviewCommand": start_command,
        "remotePreviewShell": shell_join(start_command),
        "liveReadyCommand": live_command,
        "liveReadyShell": shell_join(live_command) if live_command else None,
        "doesUpload": False,
        "doesReadPrivateKeyContents": False,
        "doesRecordRemoteProof": False,
        "requiresIphoneConfirmation": not args.dry_run,
        "iphoneNextStep": "Open Bitrig Remote on iPhone, refresh/reconnect to this Mac, open Agent, then select the Agent named in LIVE-READY.md.",
    }
    if start_result is not None:
        result["remotePreviewExitCode"] = start_result.returncode
        result["remotePreview"] = remote_preview_summary(start_result.stdout)
        if args.include_raw_output:
            result["remotePreviewStdout"] = start_result.stdout
            result["remotePreviewStderr"] = start_result.stderr
    if live_result is not None:
        result["liveReadyExitCode"] = live_result.returncode
        result["liveReady"] = compact_live_ready(json_stdout(live_result))
        live_next = result["liveReady"].get("nextAction") if isinstance(result.get("liveReady"), dict) else None
        if live_next:
            result["iphoneNextStep"] = str(live_next)
        if args.include_raw_output:
            result["liveReadyStdout"] = live_result.stdout
            result["liveReadyStderr"] = live_result.stderr
    if args.dry_run:
        result["status"] = "dry_run_ready"
    elif start_result and start_result.returncode != 0:
        result["status"] = "blocked_remote_preview"
    elif live_result and live_result.returncode != 0:
        result["status"] = "blocked_live_ready"
    else:
        result["status"] = "ready_to_open_on_iphone" if not args.no_run else "ready_agent_created_not_launched"
    return result


def print_text_result(payload: dict[str, Any]) -> None:
    print(f"Status: {payload['status']}")
    live_ready = payload.get("liveReady") if isinstance(payload.get("liveReady"), dict) else {}
    remote_preview = payload.get("remotePreview") if isinstance(payload.get("remotePreview"), dict) else {}
    if live_ready:
        print(f"Agent: {live_ready.get('agentName') or 'unknown'}")
        print(f"Mac live: {live_ready.get('macLive')}")
        print(f"Bundle ID: {live_ready.get('bundleId') or 'unknown'}")
        print(f"Process: {live_ready.get('process') or 'unknown'}")
    elif remote_preview:
        print(f"Remote preview: {remote_preview.get('status') or 'unknown'}")
    print()
    print("iPhone next step:")
    print(payload["iphoneNextStep"])
    if live_ready.get("proofDryRun") or live_ready.get("recordProof"):
        print()
        print("After it opens on iPhone:")
        if live_ready.get("proofDryRun"):
            print(live_ready["proofDryRun"])
        if live_ready.get("recordProof"):
            print(live_ready["recordProof"])
    if remote_preview.get("summaryPath") or live_ready.get("liveSummaryPath"):
        print()
        print("Reports:")
        if remote_preview.get("summaryPath"):
            print(f"Remote preview: {remote_preview['summaryPath']}")
        if live_ready.get("liveSummaryPath"):
            print(f"Live simulator: {live_ready['liveSummaryPath']}")
    print()
    print("Commands:")
    print(payload["remotePreviewShell"])
    if payload.get("liveReadyShell"):
        print(payload["liveReadyShell"])
    if payload.get("remotePreviewStdout"):
        print()
        print("Remote preview output:")
        print(str(payload["remotePreviewStdout"]).strip())
    if payload.get("liveReadyStdout"):
        print()
        print("Live ready output:")
        print(str(payload["liveReadyStdout"]).strip())
    if payload.get("remotePreviewStderr") or payload.get("liveReadyStderr"):
        print()
        print("Diagnostics:")
        if payload.get("remotePreviewStderr"):
            print(str(payload["remotePreviewStderr"]).strip())
        if payload.get("liveReadyStderr"):
            print(str(payload["liveReadyStderr"]).strip())


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Push a Codex iOS project into native Bitrig Agent state, verify it, and optionally launch the live simulator preview."
    )
    parser.add_argument("--new", help="Create a new lightweight Codex iOS seed project with this visible name.")
    parser.add_argument("--summary", help="Short app idea for the generated seed project.")
    parser.add_argument("--project", help="Existing local Codex iOS project path.")
    parser.add_argument("--name", help="Existing local project name to resolve through the bridge.")
    parser.add_argument("--agent-name", help="Override the visible Bitrig Agent project name.")
    parser.add_argument("--project-id", help="Adopt an existing Bitrig project id.")
    parser.add_argument("--overwrite", action="store_true", help="Replace existing local Agent files after backup.")
    parser.add_argument("--refresh-bitrig", dest="refresh_bitrig", action="store_true", default=True, help="Quit/open Bitrig during automation.")
    parser.add_argument("--no-refresh-bitrig", dest="refresh_bitrig", action="store_false", help="Do not quit/open Bitrig during automation.")
    parser.add_argument("--refresh-delay", type=float, default=5.0, help="Seconds to wait after opening Bitrig.")
    parser.add_argument("--no-run", action="store_true", help="Create and verify the Agent, but do not launch live-ready.")
    parser.add_argument("--profile", default="default", help="Profile name preserved in live-ready handoff; no upload occurs.")
    parser.add_argument("--automate-timeout", type=float, default=180.0, help="Agent automation timeout in seconds.")
    parser.add_argument("--verify-timeout", type=float, default=60.0, help="Agent verification timeout in seconds.")
    parser.add_argument("--control-timeout", type=float, default=20.0, help="Preview launch timeout in seconds.")
    parser.add_argument("--session-timeout", type=float, default=2700.0, help="Maximum bounded session time in seconds.")
    parser.add_argument("--max-repairs", type=int, default=3, help="Maximum repairs per failure class.")
    parser.add_argument("--launch-timeout", type=float, default=120.0, help="Seconds for bounded live-ready launch.")
    parser.add_argument("--no-write-live-ready", action="store_true", help="Print live-ready without writing LIVE-READY.md or proof cards.")
    parser.add_argument("--dry-run", action="store_true", help="Show the plan without changing files, Bitrig, or simulator state.")
    parser.add_argument("--include-raw-output", action="store_true", help="Include full child command stdout/stderr in the result.")
    parser.add_argument("--json", action="store_true", help="Emit JSON.")
    args = parser.parse_args()

    exactly_one_identity(args)
    if not CODEX_BRIDGE.exists():
        raise SystemExit(f"Missing Codex Bridge tool: {CODEX_BRIDGE}")
    if not LOWER_BRIDGE.exists():
        raise SystemExit(f"Missing lower bridge tool: {LOWER_BRIDGE}")

    start_command = remote_preview_command(args)
    live_command = None if args.no_run else live_ready_command(args)

    if args.dry_run:
        payload = public_result(args, start_command, None, live_command, None)
        if args.json:
            print(json.dumps(payload, indent=2, sort_keys=True))
        else:
            print_text_result(payload)
        return 0

    start_result = run_command(start_command, timeout=args.session_timeout + 60)
    live_result = None
    if start_result.returncode == 0 and not args.no_run and live_command:
        live_result = run_command(live_command, timeout=args.launch_timeout + 30)

    payload = public_result(args, start_command, start_result, live_command, live_result)
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print_text_result(payload)
    return 0 if payload["status"] in {"ready_to_open_on_iphone", "ready_agent_created_not_launched"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
