#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import plistlib
import re
from pathlib import Path
from typing import Optional


HOME = Path.home()
BITRIG_PROJECTS_JSON = HOME / "Library" / "Bitrig" / "Projects.json"
DEFAULT_SEARCH_ROOTS = [
    HOME / "Documents",
    HOME / "Developer",
    HOME / "Desktop",
]
GENERIC_NAMES = {"newproject", "new-project", "project", "app", "agent", "untitled", "new"}
SKIP_DIRS = {
    ".build",
    ".git",
    ".swiftpm",
    "DerivedData",
    "Library",
    "node_modules",
    "Pods",
    "build",
    "dist",
    ".venv",
    "venv",
}


def sanitize_name(value: str) -> str:
    parts = re.findall(r"[A-Za-z0-9]+", value)
    if not parts:
        return "CodexAgentProject"
    return "".join(part[:1].upper() + part[1:] for part in parts)


def bundle_slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or "codex-agent-project"


def read_source_name(path: Path) -> str:
    for xcodeproj in sorted(path.glob("*.xcodeproj")):
        return xcodeproj.stem
    for xcworkspace in sorted(path.glob("*.xcworkspace")):
        return xcworkspace.stem
    if (path / "Package.swift").exists():
        return path.name
    swift_files = sorted(path.glob("*.swift"))
    if swift_files:
        return path.name
    return path.name


def detect_ios_capability(path: Path) -> dict:
    swift_files = sorted(path.rglob("*.swift"))[:20] if path.exists() else []
    markers = {
        "xcodeproj": [str(p) for p in sorted(path.glob("*.xcodeproj"))] if path.exists() else [],
        "xcworkspace": [str(p) for p in sorted(path.glob("*.xcworkspace"))] if path.exists() else [],
        "packageSwift": (path / "Package.swift").exists() if path.exists() else False,
        "projectYml": (path / "project.yml").exists() if path.exists() else False,
        "swiftFiles": [str(p) for p in swift_files],
    }
    markers["iosCapable"] = bool(
        markers["xcodeproj"]
        or markers["xcworkspace"]
        or markers["packageSwift"]
        or markers["projectYml"]
        or markers["swiftFiles"]
    )
    return markers


def load_existing_bitrig_names() -> set[str]:
    if not BITRIG_PROJECTS_JSON.exists():
        return set()
    try:
        data = json.loads(BITRIG_PROJECTS_JSON.read_text(encoding="utf-8"))
    except Exception:
        return set()
    return {str(project.get("name")) for project in data.values() if project.get("name")}


def load_bundle_names(path: Path) -> list[str]:
    names: list[str] = []
    if not path.exists():
        return names
    for info in path.rglob("Info.plist"):
        try:
            with info.open("rb") as fh:
                plist = plistlib.load(fh)
            display = plist.get("CFBundleDisplayName") or plist.get("CFBundleName")
            if display and display not in names:
                names.append(str(display))
        except Exception:
            continue
    return names[:5]


def path_depth(root: Path, path: Path) -> int:
    try:
        return len(path.relative_to(root).parts)
    except ValueError:
        return 999


def find_project_by_name(name: str, roots: list[Path], max_depth: int = 5) -> Optional[Path]:
    wanted = sanitize_name(name).lower()
    candidates: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for current, dirnames, filenames in os.walk(root):
            current_path = Path(current)
            depth = path_depth(root, current_path)
            if depth > max_depth:
                dirnames[:] = []
                continue
            dirnames[:] = [item for item in dirnames if item not in SKIP_DIRS and not item.startswith(".")]
            child_key = sanitize_name(current_path.name).lower()
            if child_key == wanted:
                candidates.append(current_path)
                if detect_ios_capability(current_path).get("iosCapable"):
                    return current_path
                continue
            for dirname in dirnames:
                if dirname.endswith(".xcodeproj") and sanitize_name(Path(dirname).stem).lower() == wanted:
                    candidates.append(current_path)
                    return current_path
    return sorted(candidates, key=lambda item: str(item))[0] if candidates else None


def make_agent_name(source_name: str, source_path: Optional[Path], override: Optional[str]) -> str:
    base = sanitize_name(override or source_name)
    if bundle_slug(base) in GENERIC_NAMES:
        base = "CodexAgentProject"
    if not base.endswith("Agent"):
        base = f"{base}Agent"
    existing = load_existing_bitrig_names()
    if base not in existing:
        return base
    identity = str(source_path) if source_path else source_name
    suffix = hashlib.sha1(identity.encode("utf-8")).hexdigest()[:6].upper()
    return f"{base}{suffix}"


def generic_name_result(name: str) -> dict:
    return {
        "agentName": None,
        "name": None,
        "sourceProjectName": name,
        "sourceProjectPath": None,
        "needsUserConfirmation": True,
        "question": "What Codex iOS project path or specific project name should Bitrig Agent represent?",
        "reason": "Generic project names are not safe because Bitrig can group them with unrelated New Project entries.",
        "markers": {"iosCapable": False},
        "bundleNames": [],
        "prompt": None,
    }


def marker_summary(markers: dict, bundle_names: list[str]) -> str:
    summary = []
    if markers.get("xcodeproj"):
        summary.append(f"Xcode project: {Path(markers['xcodeproj'][0]).name}")
    if markers.get("xcworkspace"):
        summary.append(f"Workspace: {Path(markers['xcworkspace'][0]).name}")
    if markers.get("packageSwift"):
        summary.append("Package.swift present")
    if markers.get("projectYml"):
        summary.append("project.yml present")
    if bundle_names:
        summary.append("Bundle display names: " + ", ".join(bundle_names))
    if markers.get("swiftFiles") and not summary:
        summary.append("Swift/iOS source files detected")
    return "; ".join(summary) if summary else "Project identity supplied by user"


def build_prompt(agent_name: str, source_name: str, source_path: Optional[Path], markers: dict, bundle_names: list[str]) -> str:
    source_path_text = str(source_path) if source_path else "not yet resolved; ask the user to confirm the source checkout path before final build"
    bundle_id = f"app.bitrig.agent.{bundle_slug(agent_name)}"
    return (
        f"Create a native Bitrig Agent iPhone project named {agent_name} using Codex. "
        f"Use the visible Agent project name {agent_name} everywhere Bitrig indexes project names; do not leave it named New Project. "
        "Create this as a native Bitrig Agent project, not Classic. "
        "Create a real buildable iOS app target, not just metadata: include a SwiftUI App entry point, a ContentView, an iOS application target, "
        "a unique PRODUCT_BUNDLE_IDENTIFIER, and enough UI that it runs in the Bitrig/Xcode iPhone simulator like a normal app. "
        "Build a lightweight SwiftUI shell that represents the local Codex iOS project "
        f"{source_name} at {source_path_text}. "
        "Do not copy or compile the entire source checkout unless needed for a tiny preview shell. "
        "Keep the source project name and checkout path visibly on screen so the user knows what this Agent project represents. "
        f"Detected project context: {marker_summary(markers, bundle_names)}. "
        "Keep the Bitrig app iPhone-only and SwiftUI-based. "
        f"Use a unique target name {agent_name} and unique bundle identifier {bundle_id}; never reuse the source app bundle ID for this Agent shell. "
        "Create a local BitrigAgent.json file in the Bitrig project root with JSON metadata: "
        f'kind "agent-project", name "{agent_name}", sourceProjectName "{source_name}", '
        f'sourceProjectPath "{source_path_text}", platforms ["iPhone"], bundleIdentifier "{bundle_id}", and a short projectSummary. '
        "After creating the project, build and run it in the iPhone simulator so Bitrig Remote can open the native Agent preview."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Prepare a native Bitrig Agent project prompt for a Codex iOS project.")
    parser.add_argument("--project", help="Absolute or relative path to the Codex iOS project")
    parser.add_argument("--name", help="Project name to search for, or visible Agent name override when --project is supplied")
    parser.add_argument("--agent-name", help="Explicit visible Bitrig Agent project name override")
    parser.add_argument("--search-root", action="append", default=[], help="Additional root to search when only --name is provided")
    parser.add_argument("--max-depth", type=int, default=5, help="Maximum folder depth to search when only --name is provided")
    parser.add_argument("--output", help="Write prompt to this file")
    parser.add_argument("--json", action="store_true", help="Print JSON metadata instead of plain prompt")
    args = parser.parse_args()

    project: Optional[Path] = None
    if not args.project and args.name and bundle_slug(args.name) in GENERIC_NAMES:
        result = generic_name_result(args.name)
        if args.json:
            print(json.dumps(result, indent=2, sort_keys=True))
            return 0
        raise SystemExit(result["question"])

    if args.project:
        project = Path(args.project).expanduser().resolve()
        if not project.exists():
            raise SystemExit(f"Project path does not exist: {project}")
        if not project.is_dir():
            raise SystemExit(f"Project path is not a directory: {project}")
    elif args.name:
        roots = [Path(root).expanduser().resolve() for root in args.search_root] + DEFAULT_SEARCH_ROOTS
        project = find_project_by_name(args.name, roots, max_depth=args.max_depth)

    if not project and not args.name:
        raise SystemExit("Missing identity: provide --project /path/to/checkout or --name ProjectName")

    source_name = read_source_name(project) if project else sanitize_name(args.name or "")
    markers = detect_ios_capability(project) if project else {"iosCapable": False}
    if project and not markers["iosCapable"]:
        raise SystemExit(f"No iOS-capable project markers found in {project}")

    bundle_names = load_bundle_names(project) if project else []
    agent_override = args.agent_name or (args.name if args.project else None)
    agent_name = make_agent_name(source_name, project, agent_override)
    prompt = build_prompt(agent_name, source_name, project, markers, bundle_names)

    result = {
        "projectPath": str(project) if project else None,
        "name": agent_name,
        "agentName": agent_name,
        "sourceProjectName": source_name,
        "sourceProjectPath": str(project) if project else None,
        "needsUserConfirmation": project is None,
        "markers": markers,
        "bundleNames": bundle_names,
        "bundleIdentifier": f"app.bitrig.agent.{bundle_slug(agent_name)}",
        "prompt": prompt,
    }

    if args.output:
        output = Path(args.output).expanduser()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(prompt + "\n", encoding="utf-8")

    if args.json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(prompt)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
