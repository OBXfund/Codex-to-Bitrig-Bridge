# Bitrig Agent Project Bridge

This repository contains the Codex plugin source for `bitrig-agent-project-bridge`.

The plugin installs a skill that turns a local Codex-created iOS checkout into a uniquely named native Bitrig Agent project for Bitrig Remote. It is designed to avoid Classic imports, generic `New Project` identities, and metadata-only records that Bitrig later prunes.

## Contents

- `.codex-plugin/plugin.json`: Codex plugin manifest.
- `skills/bitrig-agent-project-bridge/SKILL.md`: Skill workflow and operating rules.
- `skills/bitrig-agent-project-bridge/scripts/prepare_bitrig_agent_prompt.py`: Resolves source project identity and writes the Bitrig Agent creation prompt.
- `skills/bitrig-agent-project-bridge/scripts/push_codex_ios_to_bitrig_agent.py`: One-command bridge wrapper for remote preview and live-ready handoff.
- `skills/bitrig-agent-project-bridge/scripts/verify_bitrig_agent_project.py`: Verifies native Agent state in Bitrig metadata.
- `skills/bitrig-agent-project-bridge/references/native-agent-workflow.md`: Additional workflow notes.

## Validate

```bash
python3 ~/.codex/skills/.system/plugin-creator/scripts/validate_plugin.py .
python3 ~/.codex/skills/.system/skill-creator/scripts/quick_validate.py skills/bitrig-agent-project-bridge
```

## Runtime Paths

`push_codex_ios_to_bitrig_agent.py` defaults to the local Bitrig bridge tools already used on this machine. To override them:

```bash
BITRIG_CODEX_BRIDGE=/path/to/codex_to_bitrig_remote_viewer.py \
BITRIG_LOWER_BRIDGE=/path/to/codex_iphone_to_bitrig.py \
python3 skills/bitrig-agent-project-bridge/scripts/push_codex_ios_to_bitrig_agent.py --dry-run --project /path/to/ios/project
```
